import 'package:flutter_test/flutter_test.dart';
import 'package:wardelva/core/tokens.dart';
import 'package:wardelva/data/catalog.dart';
import 'package:wardelva/data/models.dart';
import 'package:wardelva/state/app_state.dart';

void main() {
  final bouquet = Catalog.byCategory('bouquets').first;
  final cheap = Catalog.products.reduce((a, b) => a.basePrice < b.basePrice ? a : b);

  test('كل منتج له اسم وسعر وصورة', () {
    expect(Catalog.products, isNotEmpty);
    for (final product in Catalog.products) {
      expect(product.name.trim(), isNotEmpty);
      expect(product.basePrice, greaterThan(0));
      expect(product.imageUrl.startsWith('https://'), isTrue);
    }
  });

  test('حساب سعر المنتج مع الحجم والإضافات', () {
    final item = CartItem(
      product: bouquet,
      size: Catalog.sizes[1],
      addOns: [Catalog.addOns.first],
    );
    expect(item.unitPrice, bouquet.basePrice + Catalog.sizes[1].extra + Catalog.addOns.first.price);
  });

  test('التوصيل مجاني فوق الحد', () {
    final state = AppState();
    final expensive = Catalog.products.firstWhere((p) => p.basePrice >= WRules.freeDeliveryOver);
    state.addToCart(CartItem(product: expensive));
    expect(state.deliveryFee, 0);
  });

  test('رسوم التوصيل تُضاف تحت الحد', () {
    final state = AppState();
    state.addToCart(CartItem(product: cheap));
    expect(state.deliveryFee, WRules.deliveryFee);
    expect(state.total, cheap.basePrice + WRules.deliveryFee);
  });

  test('إنشاء طلب يفرغ السلة ويولد رقماً', () {
    final state = AppState();
    state.addToCart(CartItem(product: bouquet));
    final order = state.placeOrder(
      delivery: const DeliveryDetails(recipient: 'سارة', phone: '0555', district: 'الملقا'),
      paymentMethod: 'مدى',
    );
    expect(order.code.startsWith('WD-'), isTrue);
    expect(state.cart, isEmpty);
    expect(state.orders.length, 1);
  });

  test('النقاط تُضاف عند التسليم', () {
    final state = AppState();
    state.addToCart(CartItem(product: bouquet));
    final order = state.placeOrder(
      delivery: const DeliveryDetails(recipient: 'سارة', phone: '0555', district: 'الملقا'),
      paymentMethod: 'مدى',
    );
    final before = state.points;
    while (order.status != OrderStatus.delivered) {
      state.advance(order);
    }
    expect(state.points, before + order.earnedPoints);
  });
}
